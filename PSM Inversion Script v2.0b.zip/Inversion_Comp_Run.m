%% Script to compare four inversion methods (step-wise, kernel, HA and EM)
% Compliments manuscript: Chan et al 2019
% Author: Tommy Chan (tommy.chan@helsinki.fi)
% Date: 2019.11.28 - Last updated: 2020.10.01

%Updates
%v1.1b: Includes step-inversion (beta)
%v1.1c: bug fixes on EM method
%v2.0b: **(beta)** Introduced smoothing spline for calibration curve
%       fitting (and quality check (one direction). Bug fixes for all
%       inversions and algorithm change to derive kernels

clear all
close all

%% User inputs

% Enter data directory *place all raw PSM dat to be analyzed
DatFolder = 'C:Data\';

% Enter saving directory
paths.save='C:Data\saves\';

% Enter calibration file
path_calib ='C:Data\calib_file.txt';

% Enter inversion method
% (1: Step-wise, 2: Kernel, 3: Hagen and Alofs, 4: Expectation-maximization algorithm)
method = 4;

% Enter PSM instrument
% (1: Normal, 2: Correction)
psm = 1; % Correction for A20s with older firmware

% Enter PSM data recording mode
% (1: stepping, 2: scanning)
mode = 2; % Only scanning mode at the moment!!

% Saving (1/0; on/off)
wanttosave = 1;

% Smoothen raw data (1/0; on/off)
pre_filtering = 1; % filter before inversion
pre_method = 'lowess'; % 'lowess' | 'moving' - loess or moving average
window_pre = 12; % 6 span of the filtering (in seconds)
post_filtering = 1; % filter after inversion

% Data quality pre-treatment (1/0; on/off)
qualitycheck = 1; 

% Fitting model profile for calibration file
% (1: exponential (2nd deg), 2: power, 3: polynomial (5 deg), 4:
% exponential (1st deg), 4: polynomial (3 deg), 5: Smoothing spline
fitting = 5;

% Enter diameter size bins (largest to smallest)
% Note errors may arise during inversion process: adjust max and min bins
dia = [3.1 2.8 2.5 2.0 1.7 1.5 1.35 1.25];

% Line losses correction (0:1:2 - None:Xue Mo:Lehtipalo)
% Xue Mo = with core sampler
% Lehtipalo = Gormley-Kennedy
core_sampling = 0;

% Diluter installation (1/0; on/off)
diluter = 0;
dilution = 10; % Dilution factor

%%

if wanttosave==1
    savingpath=paths.save;
    if exist(savingpath,'dir') == 0
        mkdir(savingpath)
    end
end

if ~isdir(DatFolder)
  errorMessage = sprintf('Error: The following folder does not exist:\n%s', DatFolder);
  uiwait(warndlg(errorMessage));
  return;
end

filePattern = fullfile(DatFolder, '*.dat');
datFiles = dir(filePattern);

for i = 1:length(datFiles)
    baseFileName = datFiles(i).name;
    fullFileName = fullfile(DatFolder, baseFileName);
    disp(' ')
    fprintf(1, 'Now reading %s\n', baseFileName);
    if mode == 1
        %Run Step inversion script
        Inversion_Comp_Step(baseFileName, fullFileName, wanttosave, savingpath, path_calib, dia, fitting, psm, pre_filtering, pre_method, window_pre, method, core_sampling, mode, qualitycheck, diluter, dilution, post_filtering);
    elseif mode == 2
        %Run Scan inversion script
        Inversion_Comp_Scan(baseFileName, fullFileName, wanttosave, savingpath, path_calib, dia, fitting, psm, pre_filtering, pre_method, window_pre, method, core_sampling, mode, qualitycheck, diluter, dilution, post_filtering);
    end
end

disp('===== All files processed =====')
disp(' ')
