function conc = Fudan_Gap(conc);
%% This script calculates the CPC gap difference and removes it

% Created: 25.06.2018
% Modified: 11.09.2018


%% User entry

% NaN high noise values
% ** Added because problems with some dates e.g. 0227 **
% ==== USE WITH CAUTION =====
highnoise = 0;

%% Data management

% Columns to plot
TC_fd = conc(:,2); % Total concentration
SF_fd = conc(:,4); % Saturation flow rate

%% Manipulate data

figure(1)
plot(SF_fd,TC_fd,'.')
xlabel('Saturator flow rate(LPM)','FontSize',12)
ylabel('Number concentration (# cm^{-3})','FontSize',12)
title('Raw data')
set(gca,'FontSize',12)

% CPC correct remove diffusion losses first
TC_fd_UD = [];

for i = 1:length(TC_fd);
    TC_fd_UD = [TC_fd_UD; (TC_fd(i) .* 2.5) ./ (SF_fd(i) + 2.5)];
end

% NaN values greater than 10e5
if highnoise == 1
    indice = find(abs(TC_fd_UD) >= 9.5e4);
    TC_fd_UD(indice) = NaN; 
end

% Find maximum gap (>=3.1e4)
maxvalue = TC_fd_UD;
maxvalue(maxvalue <= 3.1e4) = NaN;
maxvalue = min(maxvalue);

% Find minimum gap (<=3.09e4)
minvalue = TC_fd_UD;
minvalue(minvalue >= 3.1e4) = NaN;
minvalue = max(minvalue);
maxdiff = maxvalue - minvalue;

% Plot of undiluted concentrations
figure(2)
plot(SF_fd,TC_fd_UD,'.')
xlabel('Saturator flow rate(LPM)','FontSize',12)
ylabel('Number concentration (# cm^{-3})','FontSize',12)
title('Raw data with diffusion losses uncorrected')
set(gca,'FontSize',12)

xLim = get(gca,'XLim'); % Create max min line
line(xLim,[minvalue minvalue],'Color','r');
line(xLim,[maxvalue maxvalue],'Color','r');

% Subtracting values greater than 3.1 by gap difference
indice = find(TC_fd_UD > 3.1e4);
TC_fd_UD(indice)=TC_fd_UD(indice) - maxdiff;

% Plot of undiluted concentrations, with gap removed
figure(3)
plot(SF_fd,TC_fd_UD,'.')
xlabel('Saturator flow rate(LPM)','FontSize',12)
ylabel('Number concentration (# cm^{-3})','FontSize',12)
title('Gap removed')
set(gca,'FontSize',12)

clear indice maxdiff maxvalue minvalue i xLim time highnoise

%% Final export

close all

% Add diffusion losses correction
TC_fd_Corr = [];
TC_fd_Corr = (TC_fd_UD ./ 2.5) .* (SF_fd + 2.5);

% Plot of diluted concentrations before gap removal
figure(4)
plot(SF_fd,TC_fd,'.')
xlabel('Saturator flow rate(LPM)','FontSize',12)
ylabel('Number concentration (# cm^{-3})','FontSize',12)
title('Original raw data')
set(gca,'FontSize',12)

% scatterplot of diluted concentrations after gap removal
figure(5)
plot(SF_fd,TC_fd_Corr,'.')
xlabel('Saturator flow rate(LPM)','FontSize',12)
ylabel('Number concentration (# cm^{-3})','FontSize',12)
title('Processed raw data')
set(gca,'FontSize',12)

conc(:,2) = TC_fd_Corr; % Save for export to main file
