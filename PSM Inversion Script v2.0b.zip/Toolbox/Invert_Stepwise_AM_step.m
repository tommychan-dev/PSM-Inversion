function [dat_inv, timenew_avg] = Invert_Stepwise(conc, dia, y1, y2, y3, dia_cut, calibFile);
%% Preparation for step-wise calculation and inversion

% Adapted from AIRMODUS A11 inversion code for scanning raw (.dat) data 
% v.1.0 by Joonas Vanhanen (joonas.vanhanen@airmodus.com)

%% Import data 

time = conc(:,1);
totalconc = conc(:,2);
partsize = conc(:,3);
satflow = conc(:,4);

%% Find min and max saturator flow rates

flowmax = round(100*max(satflow))/100;
flowmin = 0.1;

%% Define the bins for saturator flow rates

apu = 0:1:length(dia_cut);
a = (flowmax/flowmin).^(1/(length(dia_cut)));
P0 = flowmax./a.^length(dia_cut);
% satflowAM = P0.*a.^apu;
satflowAM = y3;

%% Search number of scans

k1 = find(satflow == flowmin);
k2 = min(k1);

nscan = [];

for i = 1:length(satflow)
    if i < length(satflow)
        if i <= k2
            nscan(i) = 0;
        elseif satflow(i) == flowmax & satflow(i+1) ~= flowmax;
%             nscan(i) = nscan(i-1)+1;
            nscan(i) = nscan(i-1)+1;
        else
            nscan(i) = nscan(i-1);
        end
    end
    
    if i == length(satflow)
        nscan(i) = nscan(i-1);
    end
end

if isempty(nscan)
    disp('No scans found in the data file')
    return
end

clear k1 k2 i

nscan = nscan' + 1; % Make first scan 1 (not 0)
%% Averaging over a full scan and to bins

timenew_avg = []; conc1b = []; meanflow = []; diameter = [];

lr=length(satflowAM);
for i = 1:max(nscan)
    k = find(nscan == i);
    timenew_avg(i) = min(time(k)); % Time stamp from beginning of one scan
    for iii = 1:lr-1
        meanflow(iii) = (satflowAM(iii+1)+satflowAM(iii))/2;
        diameter(iii) = (dia(iii+1)+dia(iii))/2;
    end
    
    for ii = 1:lr
        if ii == 1
            k1 = find(satflow<meanflow(ii) & satflow>satflowAM(ii) & nscan == i);
            conc1b(i,ii) = nanmean(totalconc(k1));
        elseif ii<lr & ii>1
            k1 = find(satflow>meanflow(ii-1) & satflow<meanflow(ii) & nscan == i);
            conc1b(i,ii) = nanmean(totalconc(k1));
        elseif ii == lr
            k1 = find(satflow>meanflow(ii-1) & satflow<satflowAM(ii) & nscan == i);
            conc1b(i,ii) = nanmean(totalconc(k1));
        end
    end
end

clear k k1

%% Find all data with diameter larger than the largest bin

ft2 = fit(calibFile(:,2),calibFile(:,3),'power2');
DETEFF = ft2(diameter);

k = find(round(100.*satflow)./100 == flowmin);

clear k

%% Check the quality of each scan

M = [];

for i = 1:size(conc1b,1)
    Cmax = nanmax(conc1b(i,:));
    cf = polyfit(satflowAM,conc1b(i,:)./Cmax,1);
    M(i,:) = [i,cf(2)];
end

k = isnan(conc1b);
conc1b(k) = 0;
clear k

dconc=[];
for i=1:lr-1
    dconc(:,i)=((conc1b(:,i+1)-conc1b(:,i)))./DETEFF(i);
end

%% Set all scans with no small particles to 0

for i = 1:size(dconc,1)
    if M(i,2) < 0
        dconc(i,:) = 0;
    end
end

%% Set all the negative values to zero

% dconc=max(dconc,0); % Used in Airmodus script, but not here

%% Prepare data for next section
dat_inv = dconc;
