function y=Gauss_Dist(x,param,nr_peaks,nr_param)
%
%Gaussian distribution
%
%
%h
%w
%z

if ~ isstruct(param)
    %    calculating the distribution 
    if isnumeric(x) 
        x=x(:);
        x=x(:,ones(1,nr_peaks));
        lng=size(x,1);
        
        
        h  = param(1:nr_peaks);               h  = h(ones(lng,1),:);
        w  = param(nr_peaks+1:nr_peaks*2);    w  = w(ones(lng,1),:);
        z  = param(nr_peaks*2+1:nr_peaks*3);  z  = z(ones(lng,1),:);
        
    elseif isstruct(x) && strcmp(x.type,'GA_data')
        str=x;
        x=1:str.d_smpl.d_step:str.d_smpl.d_max;
        x=x(:);
        x=x(:,ones(1,nr_peaks));
        lng=size(x,1);
        
        
        switch str.ga.fit_param
        case 'min_param'
            
            h  = param(1:nr_peaks);               h  = h(ones(lng,1),:);
            w  = param(nr_peaks+1:nr_peaks*2);    w  = w(ones(lng,1),:);
            z = str.peaks.top;                    z  = z(ones(lng,1),:);
            
        case 'max_param'
                    
            h  = param(1:nr_peaks);               h  = h(ones(lng,1),:);
            w  = param(nr_peaks+1:nr_peaks*2);    w  = w(ones(lng,1),:);
            z  = param(nr_peaks*2+1:nr_peaks*3);  z  = z(ones(lng,1),:);
            
        end
    else
        error('Input can only be a data or structure made by MS_makedat!')
    end
    
    %c1=h./(w.*2.5066);
%     c1=h./(2.5066);
% x
% z
 c1=h;
    c2=(x-z).^2;
    c3=2.*(w.^2);

%calculate
% w
y=c1.*exp(-(c2./c3));

    
%     y=h.*exp(-(x-z).^2./(1.*w.^2));
    
elseif isstruct(param),
    %parameter settings    
    if strcmp(param.type,'MS_peaks')
        top=param.top;
        strt=param.strt;
        ntop=param.ntop;
        fit_param=param.ga.fit_param;
    elseif strcmp(param.type,'GA_data')
        top=param.peaks.top;
        strt=param.peaks.strt;
        ntop=param.peaks.ntop;
        fit_param=param.ga.fit_param;
    else
        error('Wrong type of structure!')
    end
    nr_g=length(top);
    
    lng=length(x);
    
    %initial values
    y=struct('type','gauss_init_param','nr_peaks',[],'nr_param',[],'limits',[],'init',[]);
    
    Init_h=ntop;
    Init_w=ones(1,nr_g)*10;
    Init_z=top;
    
    h_lb=Init_h*0.8;
    w_lb=ones(1,nr_g);
    z_lb=top-lng*.05;
    
%     h_hb=min(Init_h+.05,max(param.dat)); % 1 is absolute maximum
    h_hb=Init_h;
    w_hb=ones(1,nr_g)*10;
    z_hb=top+lng*.05;
    
    switch fit_param
    case 'min_param'
        low_bounds=[h_lb,w_lb];
        high_bounds=[h_hb,w_hb];
        
        y.nr_param=2;
        y.init=[Init_h,Init_w];
        
    case 'max_param'
        low_bounds=[h_lb,w_lb,z_lb];
        high_bounds=[h_hb,w_hb,z_hb];
        
        y.nr_param=3;
        y.init=[Init_h,Init_w,Init_z];
    end    
    VLUB = [low_bounds;high_bounds];
    y.nr_peaks=nr_g;
    y.limits=VLUB;
end