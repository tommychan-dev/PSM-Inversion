function dN = Invert_HA_2(dj_mid, ddj, eff, di, di_lim, Ri, dp_lim)
% number of inversion; the inversion is performed many times with random 
% detachments from the rawcounts to obtain smoother curves
% let n_try = 1 if you don't like the detach & average method
n_try = 1;
std_dev = 0.00; % relative standard deviation for detachment % Not used in ambient data --noise
if n_try <= 1 || n_try > 100
    n_try = 1;
    std_dev = 0;
end
%% Generate a matrix for random inputs

Ri_input = zeros(n_try,length(Ri));

for i = 1:size(Ri_input,1)
    if std_dev >0
        Ri_input(i,:) = random('norm', Ri, Ri*std_dev);
    else
        Ri_input(i,:) = Ri;
    end
end

% initialize the matrixes and vectors in the H&A method
% Matrix G(I*J)
G_R = eff';
% Vector ij, denotes the value of i such di is nearest to dj_mid
% First we must find a reasonable di corrsponding to si
ij_R = ones(1,length(dj_mid));
for j = 1:length(dj_mid)
    [~,ij_R(j)] = min(abs(di-dj_mid(j)));
end

P_interp_R = zeros(1,length(dj_mid)); % For interpolation, not any efficiency
Y_interp_R = ones(1,5);
z_interp_R = ones(1,5);
gamma_interp_R = zeros(1,length(dj_mid));
Fj_R = ones(1,length(dj_mid));
ni = ones(size(Ri_input,1), length(Ri));

% do H&A inversion for n_try times
for n_random = 1:n_try
    % Three times of iteration
    for cyc = 1:3
        % Calculate Matrix P_interp (1*J)
        if cyc > 1
            for i = 1:length(Ri)
                if i < 3
                    k_add_num = 0; % corresponding to which five points for interpolation
                elseif i > length(Ri)-2
                    k_add_num = length(Ri)-5;
                else
                    k_add_num = i-3;
                end
                for k = 1:5
                    Y_interp_R(k) = log(ni(k+k_add_num));
                    z_interp_R(k) = log(di(k+k_add_num));
                end
                P_interp_R(i) = (5*sum(z_interp_R.*Y_interp_R) - sum(z_interp_R)*sum(Y_interp_R)) / (sum(z_interp_R)^2 - 5*sum(z_interp_R.^2));
                P_interp_R(isnan(P_interp_R)) = 0; % Added by Runlong 
                if abs(P_interp_R(i)) > 8
                    for k = 1:5
                        z_interp_R(k) = di(k+k_add_num);
                    end
                    gamma_interp_R(i) = (5*sum(z_interp_R.*Y_interp_R) - sum(z_interp_R)*sum(Y_interp_R)) / (sum(z_interp_R)^2 - 5*sum(z_interp_R.^2));
                end
                gamma_interp_R(isnan(gamma_interp_R)) = 0; % Added by Runlong 
            end
        end
        % Calculate Matrix Fj (1*J)
        for j = 1:length(dj_mid)
            if abs(P_interp_R(ij_R(j))) <= 8
                Fj_R(j) = (di(ij_R(j))/dj_mid(j))^P_interp_R(ij_R(j));
            else
                Fj_R(j) = exp(-gamma_interp_R(ij_R(j))*(dj_mid(j)-di(ij_R(j))));
            end
        end
        % Calculate Matrix Q (I*I)
        Q_R = zeros(length(Ri),length(Ri));
        for i = 1:length(Ri)
            for k = 1:length(Ri)
                for j = 1:length(dj_mid)
                    if ij_R(j) == k
                        Q_R(i,k) = Q_R(i,k) + ddj*G_R(i,j)*Fj_R(j);
                    end
                end
            end
        end
        
        ni(n_random,:) = lsqnonneg(Q_R,Ri_input(n_random,:)');
        %     Ni = ni*ddi;
    end
end

% Calculate the mean value of dN/ddp at each di
if n_try >1
    ni_ave = mean(ni);
else
    ni_ave = ni;
end
Ni = ni_ave.* (di_lim(2:end) - di_lim(1:end-1));
dN = fliplr( Mergebin(di_lim(1:end-1),Ni(1:end-1),fliplr(dp_lim)) );
end