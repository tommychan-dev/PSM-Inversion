function dN = Invert_EM_2(dj_mid, eff, Ri, dp_lim);
% Variable claim
% dj_mid: mean particle diameter of each size bin, has to be linear
% eff(si, dj_mid): detection efficiency
% Ri: total counts at each saturator flow rate, si
% note that si is not needed in the inversion function
% dp_lim: the desired upper or lower limit of each size bin



% Estimate H(i,j)
H = eff';
% Assume a initial array of Nj
Nj = ones(1,length(dj_mid));
Rj = ones(1,length(dj_mid));
Rij = zeros(length(Ri),length(dj_mid));
for cyc = 1:1000
    % Update Rj
    Nj_old = Nj;
    for j = 1:length(Rj)
        for i = 1:length(Ri)
            Rij(i,j) = Ri(i)*H(i,j)*Nj(j)/sum(H(i,:).*Nj);
        end
        Rj(j) = sum(Rij(:,j));
        Nj(j) = Rj(j)/sum(H(:,j));
    end
    if max((Nj-Nj_old) ./ Nj) < 9e-3 % 2e-4 (original) or 9e-3 (more physically possible)
        break;
    end
end

dN = fliplr( Mergebin(dj_mid(1:end-1),Nj(1:end-1),fliplr(dp_lim)) );
end