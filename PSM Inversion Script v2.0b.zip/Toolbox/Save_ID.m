function [fileid1, fileid2, fileid3] = Save_ID(psm, mode, method);

if psm == 1
        fileid1 = ['PSM'];
    elseif psm == 2
        fileid1 = ['PSM - Corrected'];
    else
        fileid1 = ['PSM'];
end

if mode == 1
        fileid2 = ['Step'];
    else
        fileid2 = ['Scan'];
end

if method == 1
        fileid3 = ['Step-wise'];
    elseif method == 2
        fileid3 = ['Kernel'];
    elseif method == 3
        fileid3 = ['H&A'];
    else
        fileid3 = ['EM'];
end