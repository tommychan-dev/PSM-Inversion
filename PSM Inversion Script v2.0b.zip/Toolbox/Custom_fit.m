clear all; 
close all;

addpath calibration_files\

save_name='PSM_container_2018_7_13_onwards_det.mat';

calib='PSM5_hydeerr_16-Jul-2018.txt'; %PSM6err_14-May-2018.txt';


cal = load(calib);
sat=cal(:,1);
di=cal(:,2);
ef=cal(:,3);
sigma=cal(:,4);
w=1./sigma.^2;
[xData, yData] = prepareCurveData( di,sat );
[xData, yData2] = prepareCurveData( di,ef );
cftool


%%


ft = fittype( 'smoothingspline' );
opts = fitoptions( 'Method', 'SmoothingSpline' );
opts.SmoothingParam = 0.5;
opts.Weights = w;

% Fit model to data.
[fit1, gof] = fit( xData, yData, ft, opts );

% Plot fit with data.
figure(1);
h = plot( fit1, xData, yData );
legend( h, 'yData vs. xData with w', 'untitled fit 1', 'Location', 'NorthEast' );
% Label axes
xlabel xData
ylabel yData
grid on

fit1(di)
%%

ft = fittype( 'smoothingspline' );
opts = fitoptions( 'Method', 'SmoothingSpline' );
opts.SmoothingParam = 0.009;
opts.Weights = w;

% Fit model to data.
[fit1, gof] = fit( xData, yData2, ft, opts );

% Plot fit with data.
figure(1);
h = plot( fit1, xData, yData2 );
legend( h, 'yData vs. xData with w', 'untitled fit 1', 'Location', 'NorthEast' );
% Label axes
xlabel xData
ylabel yData
grid on

fit1(di)

%%

if exist(save_name,'file') == 2
        % check if calinration with same name already exist
        promptMessage = sprintf('file already exist do you want to save anyway?  Yes or No?');
        titleBarCaption = ' save anyway?';
        numberOfUsers = 1;
        buttonSelections = zeros(1, numberOfUsers); % Preallocate.
        for userNumber = 1 : numberOfUsers
            button = questdlg(promptMessage, titleBarCaption, 'Yes', 'No', 'No');
            if strcmpi(button, 'Yes')
                     save(save_name,'fit1');
            else

            end
        end
    else   
        save(save_name,'fit1');
end
    



