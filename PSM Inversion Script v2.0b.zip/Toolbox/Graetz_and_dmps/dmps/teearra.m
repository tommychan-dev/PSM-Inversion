function teea=teearra(p,dp,t,press,voltage,pituus,arkaksi,aryksi,qa,qc,qm,qs)


beta=(qs+qa)/(qm+qc);

delta=-(qs-qa)/(qs+qa);

gammas=(aryksi/arkaksi)*(aryksi/arkaksi);

gkappa=pituus*arkaksi/(arkaksi*arkaksi-aryksi*aryksi);

gammai=(0.25*(1-gammas*gammas)*(1-gammas)*(1-gammas)+(5/18)* ...
(1-gammas*gammas*gammas)*(1-gammas)*log(gammas)+(1/12)*(1- ...
gammas*gammas*gammas*gammas)*log(gammas)*log(gammas))/((1-gammas)* ...
(-0.5*(1+gammas)*log(gammas)-(1-gammas))*(-0.5*(1+gammas)* ...
log(gammas)-(1-gammas)));

gabeta=(4.0*(1+beta)*(1+beta)*(gammai+(1/((2*(1+beta)* ...
gkappa)*(2*(1+beta)*gkappa)))))/(1-gammas);


zeta=zeros(length(dp),length(p));


%size(p)
%size(cunn(dp,t,press) ./dp)
%size(p*(cunn(dp,t,press) ./dp)')
zeta=(p*(e*cunn(dp,t,press) ./(3*pi*visc(t)*dp))')';
zetap=zeros(length(dp),length(p));

%size(zeta)
%pause

zetap=4.0*voltage*pi*pituus*zeta ./((qm+qc)*log(aryksi/arkaksi));

%semilogx(dp,zeta)
%pause

%semilogx(dp,zetap)
%pause

rhota=zeros(length(dp),length(p));

for i=1:length(p)
rhota(:,i)= ...
sqrt((zetap(:,i)/p(i))*(gabeta*log(aryksi/arkaksi)*boltz*t/(e*voltage)));
end

%semilogx(dp,rhota)
%pause


teea1=rhota ./(sqrt(2)*beta*(1.-delta)) .*  ...
(epsilon(abs(zetap-(1+beta)) ./(sqrt(2)*rhota))+ ...
epsilon(abs(zetap-(1-beta)) ./(sqrt(2)*rhota))- ...
epsilon(abs(zetap-(1+beta*delta)) ./(sqrt(2)*rhota))- ...
epsilon(abs(zetap-(1-beta*delta)) ./(sqrt(2)*rhota)));		

teea2=1/(2*beta*(1-delta)) .*(abs(zetap-(1+beta))+ ...
abs(zetap-(1-beta))-abs(zetap-(1+beta*delta))- ...
abs(zetap-(1-beta*delta)));
teea=teea2+teea1;
