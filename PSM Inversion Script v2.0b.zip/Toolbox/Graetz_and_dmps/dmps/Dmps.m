%Information about dmps configuration
%Temperature [K]
t=293;
%Pressure [Pa]
press=101325;


%------------------------------------------------
%Information about first DMA
%dma length [m]

%halfmini GUESS
% pituus1=0.017;
% aryksi1=0.004;
% arkaksi1=0.007;


% vienna type dma
pituus1=0.11;
aryksi1=0.025;
arkaksi1=0.033;

%tsi nano DMA
% pituus1=0.05;
% aryksi1=0.9385E-2;
% arkaksi1=1.9095E-2;

%pitk� DMA
% pituus1=0.50;
% aryksi1=0.025;
% arkaksi1=0.033;

% pituus1=0.05;
%dma outer radius [m]
% arkaksi1=3.3e-2;
%dma inner radius [m]
% aryksi1=2.5E-2; 



%Flows  [m3/s]   
%sheath flow   
qc1=10/1000/60;    
%excess flow        
qm1=10/1000/60;
qa1=4/1000/60;       
%aerosol flow out    
qs1=4/1000/60;


dp=10.^[log10(0.5e-9):0.001:log10(80e-9)]';

p=-1;
volt=500;
tr1=teearra(p,dp,t,press,volt,pituus1,arkaksi1,aryksi1,qa1,qc1,qm1,qs1);
volt=4800;
tr2=teearra(p,dp,t,press,volt,pituus1,arkaksi1,aryksi1,qa1,qc1,qm1,qs1);
volt=300;
tr3=teearra(p,dp,t,press,volt,pituus1,arkaksi1,aryksi1,qa1,qc1,qm1,qs1);

vo=10.^[log10(1):0.2:log10(10000)]';
for i=1:length(vo)
    trr(i)=max(teearra(p,dp,t,press,vo(i),pituus1,arkaksi1,aryksi1,qa1,qc1,qm1,qs1));
end


ress=[dp tr1 tr2 tr3];
%semilogx(dp,[tr1 tr2 tr3])

%Mobilities with voltages used
mob=e*cunn(dp,t,press) ./(3*pi*visc(t)*dp);


volt=(qc1+qm1)/2 * log(arkaksi1/aryksi1)/(2*pi*pituus1) * 1 ./abs(mob);

% sprintf('%15.5f %15.5f \n',[dp*1e9 volt]')

% save res.dat ress /ascii