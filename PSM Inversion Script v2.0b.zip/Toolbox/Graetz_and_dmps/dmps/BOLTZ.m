function b=boltz()
b=1.381e-23;

