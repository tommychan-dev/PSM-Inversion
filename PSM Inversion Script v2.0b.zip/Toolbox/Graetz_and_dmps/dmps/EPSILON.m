
function e=epsilon(tuntea)

 
e=-tuntea .*(1.-erf(tuntea))+(1./sqrt(pi))*exp(-tuntea .*tuntea);

