function ee=e()
ee=1.602E-19;
