function [Am] = CalcAm(lm, k_in, n_in)

k = 50;
if nargin >= 2
    k = k_in;
end

n = 100;
if nargin >= 3
    n = n_in;
end

dx = 1.0/k;
x = [0: dx : 1]';
nx = size(x, 1);
gzx = zeros(nx, 1);
rx = zeros(nx, 1);

for i = 1:nx
    gzx(i) = Graetz(x(i), lm, n);
    rx(i) = x(i) * (1 - x(i)^2);
end

numer = gzx'*rx;

gzx = gzx.^2;
denom = gzx'*rx;

Am = 1.0 * numer / denom;

end

