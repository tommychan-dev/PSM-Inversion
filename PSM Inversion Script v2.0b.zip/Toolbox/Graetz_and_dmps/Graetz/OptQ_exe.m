fprintf('Running optQ ... \n');

flag = 0;

while(flag == 0)
    fprintf('/*==================================================*/ \n');
    prompt = 'Enter the tube length L (m): \n';
    L = input(prompt);

    prompt = 'Enter diffusion coeffiency D: \n';
    D = input(prompt);

    prompt = 'Enter sample flow rate Qs (L/min): \n';
    Qs = input(prompt);
    Qs = Qs*1.e-3/60;

    prompt = 'Enter infimum limit of consentration p: \n';
    p = input(prompt);

    R = 1;
    [Q_opt, xi_opt] = OptQ(L, D, R, Qs, p);

    Q_opt = Q_opt*1000*60;

    fprintf('The optimum total flow rate Q_opt is %.6f L/min. \n', Q_opt);
    fprintf('/*==================================================*/ \n');
    
    prompt = 'Quit? [Y or N] \n';
    str = input(prompt, 's');
    if (str == 'Y')
        flag = 1;
    end
end