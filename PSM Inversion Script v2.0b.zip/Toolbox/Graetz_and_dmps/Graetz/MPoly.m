function [Mx] = MPoly(a, b, x, n_in)

n = 100;
if nargin >= 4
    n = n_in;
end

iter_a = a;
iter_b = b;
iter_x = 1.0;

coef = 1.0;
Mx = 1.0;

for i = 1:n
    coef = coef * iter_a / iter_b;
    iter_a = iter_a + 1;
    iter_b = iter_b + 1;
    
    iter_x = iter_x * x / i;
    Mx = Mx + coef * iter_x;
end

end