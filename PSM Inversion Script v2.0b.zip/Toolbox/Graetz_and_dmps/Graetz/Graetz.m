function [Gzx] = Graetz(x, l, n_in)

n = 100;
if nargin >= 3
    n = n_in;
end

lx = l*x^2;

Mx = MPoly(0.5 - 0.25*l, 1, lx, n);
Ex = exp(-0.5*lx);

Gzx = Mx*Ex;

end