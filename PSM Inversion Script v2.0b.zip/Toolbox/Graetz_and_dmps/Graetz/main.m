load('eigenvalue.mat');

t = 0.001;
x = [0: 0.02: 1]';
sx = size(x, 1);
Uxt = zeros(sx, 1);

for i = 1:sx
    Uxt(i) = CalcU(x(i), t, l);
end

Uxt = Uxt;

plot(x, Uxt);