function [dat_inv, timenew_avg] = Invert_EM(conc, ave_inversion, pvm, inv_window, dia, y1, calibFile, dia_cut);
%% Preparation for inversion

% Import variables
time = conc(:,1);
tconc = conc(:,2);
partsize = conc(:,3);
satflow = conc(:,4);

% Set start of the inversion to begin at the middle of half scan
i_start_time = find(abs(satflow-0.11) < 0.05 | abs(satflow-1.29) < 0.05,1,'first');

% If time(i_start_time) > pvm+datenum(0,0,0,0,1,0)
start_time=time(i_start_time);

timenew_avg = start_time:ave_inversion/(60*24):pvm + 1;
% r = 0.1:inv_window:max(satflow);
r = y1';
lr = size(r,2);

% Pre-allocate
conc1b=ones(length(timenew_avg),lr-1);

for i=1:lr-1   
    k=find(satflow >= r(i) & satflow <= r(i+1) & start_time < time);
    time1=time(k);
    conc1=tconc(k);
    conc1b(:,i)=Averaging_Time(time1,conc1,[timenew_avg],'median');
    clear k time1 conc1
end

%% EM Inversion, create variables (adapted from Runlong 2018)

% Define upper or lower limit of dia
di_lim = linspace(min(dia), max(dia), size(conc1b,2)+1);

% Mean values of each size bin of di_lim
di_HA = (di_lim(1:end-1) + di_lim(2:end))/2;

% Particle diameter of each size bin, has to be linear
dj = linspace(min(dia), max(dia), 51); % Remove smallest size bin of dj
% dj = linspace(min(dia), max(dia), length(di_lim)*30+1); %% This can be
% used, but takes much longer due to larger size

% Mean particle diameter of each size bin (has to be linear)
dj_mid = (dj(1:end-1)+dj(2:end))/2;

% Length of each size bin
ddj = (max(dj)-min(dj)) / (length(dj)-1);

% Determine Sat Flow Rates and DE at dj_mid
calibSat=calibFile(:,1);
calibDia=calibFile(:,2);
calibDe=calibFile(:,3);

ft1 = fit(calibDia,calibSat,'power2');
ft2 = fit(calibDia,calibDe,'power2');

y1 = ft1(dj_mid); % satflows
y2 = ft2(dj_mid); % deteff

% Length of mean particle diameter of each size bin
nrP=length(dj_mid);

%% Differentiate concentration
dconc=ones(length(timenew_avg),lr-2 ); % Pre-allocate

for i=1:lr-2
    dconc(:,i)=(conc1b(:,i+1)-conc1b(:,i));
end

% dconc=max(dconc,0); % To be determined for further use
stp = size(dj,2)-1;

for i=1:stp
     i_xs= (find(r >= y1(i),1,'first'));
     if i_xs < 1
        if ((abs( r(i_xs) - y1(i)) - abs(r(i_xs-1) - y1(i))) < 0)
            xs(i)=(i_xs-1);
        else
            xs(i)=(i_xs);
        end
     else        
         xs(i)=(i_xs);
     end
end

%% Transfer functions

fitted_width = @(q1,p1,x) p1./(x + q1);

if max(satflow) > 1.10
    % Typical width while scanning 0.1 - 1.3
    w = fitted_width(-1.004845330847514,0.057949685534591,dj_mid)./(max(satflow)./length(1:lr-2));
else
    % Typical width while scanning 0.1 - 1
    w = fitted_width(-0.847359785344075,0.037844469977517,dj_mid)./(max(satflow)./length(1:lr-2));
end

w = normalize(w, 'range', [min(w(:)) min(w(:))]);

% Height of transfer function
for i = 1:size(w,2)
    h(i) = y2(i)/(sqrt(2*pi)*w(i));
end

xs = interp1(r,1:length(r), y1, 'linear', 'extrap');
xs = xs';

%% Creating Gaussian Distribution kernels

kernel = Gauss_Dist(1:lr-2,[h,w,xs],nrP)';

eff = zeros(size(kernel,1), size(kernel,2)+1);
for ii = 1:size(eff,1)
    eff(ii,:) = y2(ii)*normcdf(0.5:lr-1.5,xs(ii),w(ii));
end
eff(eff < 0) = 0;

%% Create Inversion

for i=1:size(conc1b,1)
    dat_inv(i,:) = Invert_EM_2(dj_mid, eff, conc1b(i,:), dia);
%     disp(i); To display count
end