%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Quality check scans via statistical hypothesis testing
% *** keeps scans if p-value < 0.05 and positive, otherwise NaN ***
% Several sections adapted from Airmodus Inversion v1.0
% Tommy Chan, Sept. 05th, 2018, Helsinki
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function conc = QualityCheck(conc);

% clear all
% close all

disp(' ')
disp('===== Pre-Treatment Quality Check =====')

%% Import data and prepare for quality check

time = conc(:,1);
totalconc = conc(:,2);
partsize = conc(:,3);
satflow = conc(:,4);

%% Search number of scans

flowmin = 0.1;
flowmax = 1.3;

k1 = find(satflow == flowmin);
k2 = min(k1);

nscan = [];

for i = 1:length(satflow)
    if i < length(satflow)
        if i <= k2
            nscan(i) = 0;
        elseif satflow(i) == flowmax & satflow(i+1) ~= flowmax;
%             nscan(i) = nscan(i-1)+1;
            nscan(i) = nscan(i-1)+1;
        else
            nscan(i) = nscan(i-1);
        end
    end
    
    if i == length(satflow)
        nscan(i) = nscan(i-1);
    end
end

if isempty(nscan)
    disp('No scans found in the data file')
    return
end

clear k1 k2 i
nscan = nscan' + 1;

fprintf(1, 'Total number of scans: %d\n', max(nscan));

%% Check the quality of each scan

conc1 = [totalconc nscan];

Scan = [];

for i = 1:max(nscan)
    Nfind = find(nscan == i);
    slopeSatFlow = satflow(Nfind);
    slopeN = totalconc(Nfind);
    
    [slope,pval] = corr(slopeSatFlow, slopeN);
    Scan(i,:) = [i, pval(1), slope(1)];
  
%% Shows plot of each individual scan    
%     plot(slopeSatFlow,slopeN, '.k','markers',12) 
%     plotTitle1 = num2str(pval(1),3);
%     plotTitle2 = num2str(slope(1),3);
%     title({'pval: ' plotTitle1; 'rho: ' plotTitle2})
%     xlabel('Saturator flow rate (lpm)')
%     ylabel('N')
%     pause(0.5)
  
end

% Plot whole day scan vs slope with visual indicator of good and bad scans
aboveLine2 = (Scan(:,2) < 0.05);
bottomLine = Scan(:,2);
topLine = Scan(:,2);
bottomLine(aboveLine2) = NaN;
topLine(~aboveLine2) = NaN;

figure(1)
f1 = figure(1);
movegui('northwest');
plot(Scan(:,1),bottomLine,'.r', Scan(:,1),topLine,'.k')
title('Quality Scan Check')
xlabel('Scan number')
ylabel('p-value')
xlim([0 length(Scan)])
ylim([-0.2 1])
legend('Discarded Scan','Retained Scan')

%% NaN scans which have negative slope

goodScan = find(Scan(:,3) > 0 & Scan(:,2) < 0.05);
medScan = find(Scan(:,3) > 0 & Scan(:,2) > 0.01 & Scan(:,2) < 0.05); % Used to see which scans are if between 0.01 and 0.05
badScan = Scan(~(aboveLine2));

badScanC2 = [];

for i = 1:length(badScan)
    badScanC = find(nscan == badScan(i,1));
    badScanC2 = [badScanC2; badScanC];
end

totalconc(badScanC2) = NaN;
partsize(badScanC2) = NaN;
satflow(badScanC2) = NaN;

goodResult = (sum(aboveLine2));
badResult = length(Scan) - goodResult;

fprintf(1, 'Total number of retained scans: %d\n', goodResult);
fprintf(1, 'Total number of discarded scans: %d\n', badResult);

% Create new file and export to main script
conc = [time totalconc partsize satflow];

pause(0.5)