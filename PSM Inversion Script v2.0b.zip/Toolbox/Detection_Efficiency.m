function [y1, y2, y3, ft1, ft2, ft3] = Detection_Efficiency(calibSat, calibDia, calibDe, fitting, dia_cut, conc);

%Detection efficiency calculation and corresponding values at each cut off

%
%   calibSat = calibrational value of Saturator Flow Rate variable
%   calibDia = calibrational value of Diameter variable
%   calibDe = calibrational value of Detection Efficiency
%   Fitting = type of the fit (1: exp (default), 2: power, 3: polynomial (5 deg).)
%   dia_cut = Diameter size cut off
%   nro = 1: saturation flow rate vs. detection efficiency, 2: saturation 
%            flow rate vs. diameter, 3: diameter vs. saturation flow rate,
%            4: diameter vs. detection efficiency


disp(' ')
disp('===== Calculating detection efficiency =====')

% Turn off warning of curve fit (due to NaN from pre-treatment)
id = ['curvefit:fittype:sethandles:xMustBePositive'];
warning('off',id);

% Find fit

if fitting == 1 % exponential, 2nd deg  [y=a*exp(b*x)+c*exp(d*x)]
    ft1 = fit(calibDia,calibSat,'exp2');
    ft2 = fit(calibDia,calibDe,'exp2');
elseif fitting == 2 % power [f(x) = a*x^b+c]
    ft1 = fit(calibDia,calibSat,'power2');
    ft2 = fit(calibDia,calibDe,'power2');
elseif fitting == 3 % polynomial (5 deg)
    ft1 = fit(calibDia,calibSat,'poly5');
    ft2 = fit(calibDia,calibDe,'poly5');
elseif fitting == 4 % exp, 1st deg
    ft1 = fit(calibDia,calibSat,'exp1');
    ft2 = fit(calibDia,calibDe,'exp1');
elseif fitting == 5 % custom smoothing spline fit
    
% Taken from custom fit file
% Prepare data
[xData, yData] = prepareCurveData( calibDia,calibSat );
[xData, yData2] = prepareCurveData( calibDia,calibDe );
cftool
ft = fittype('smoothingspline');
opts = fitoptions( 'Method', 'smoothingspline' );
opts.SmoothingParam = 0.99;

% Fit and plot model to data (Diameter to Sat. Flow Rate)
[ft1, gof] = fit( xData, yData, ft, opts );

% figure(1);
% h = plot( ft1, xData, yData );
% legend( h, 'Fitted Data', 'Fit 1', 'Location', 'NorthEast' );
% % Label axes
% xlabel('Diameter')
% ylabel('Sat. Flow Rate')
% grid on

fit1 = ft1(calibDia);

% Fit and plot model to data (Diameter to Det. Eff)
[ft2, gof] = fit( xData, yData2, ft, opts );

% figure(2);
% h = plot( ft2, xData, yData2 );
% legend( h, 'Fitted Data', 'Fit 2', 'Location', 'SouthEast' );
% % Label axes
% xlabel('Diameter')
% ylabel('Det. Eff')
% grid on

fit2 = ft2(calibDia);

% Fit and plot model to data (Sat. Flow Rate to Diameter)
[ft3, gof] = fit( yData, xData, ft, opts );

% figure(3);
% h = plot( ft3, yData, xData );
% legend( h, 'Fitted Data', 'Fit 3', 'Location', 'NorthEast' );
% % Label axes
% xlabel('Sat. Flow Rate')
% ylabel('Diameter')
% grid on
% 
% fit3 = ft3(calibDia);
   
%     ft1 = cfit(calibDia,calibSat,'fit1');
%     ft2 = cfit(calibDia,calibDe,'fit1');
else
    errorMessage = sprintf('Detection Efficiency Error: Please enter a proper fitting type');
    uiwait(warndlg(errorMessage));
end

%interpolate diameter cutoff values to get corresponding y values
y1 = ft1(dia_cut); % diameter vs SFR
y2 = ft2(dia_cut); % diameter vs Det eff

%% Obtain particle size from saturator flow rate

if fitting ~= 5
    ft3 = fit(calibSat, calibDia,'power2');
end   

y3 = ft3(conc(:,4));

% Close Curve Fitting Tool
h = getappdata( groot, 'SurfaceFittingToolHandle' );  
clearSessionChanged(h);  
closeSftool(h)  

%% Figure plots
% Fig 1: diameter vs SFR
% Fig 2: diameter vs Det eff


%plots
figure(1)
movegui('northwest');
plot(ft1,calibDia,calibSat);
ylim([0 2]);
hold on
plot(dia_cut,y1,'k*');
xlabel( 'Diameter (nm)' );
ylabel( 'Saturator flow rate (lpm)' );
legend('raw data', 'fitted curve', 'fitted points', 'Location', 'NorthEast');
grid on
hold off


figure(2)
movegui('north');
plot(ft2,calibDia,calibDe);
ylim([0 1]);
hold on
plot(dia_cut,y2,'k*');
xlabel( 'Diameter (nm)' );
ylabel( 'Detection efficiency' );
legend('raw data', 'fitted curve', 'fitted points', 'Location', 'NorthEast');
grid on
hold off


%% Obtain particle size from saturator flow rate

%plots
figure(3)
movegui('northeast');
plot(ft3,calibSat,calibDia);
ylim([0 5]);
xlim([0 1.4]);
hold on
plot(conc(:,4),y3,'k*');
xlabel( 'Saturator flow rate (lpm)' );
ylabel( 'Diameter (nm)' );
legend('raw data', 'fitted curve', 'fitted points', 'Location', 'NorthEast');
grid on
hold off
pause(0.5)



