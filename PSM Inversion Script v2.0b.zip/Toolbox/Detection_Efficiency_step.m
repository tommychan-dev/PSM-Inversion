function [y1, y2, y3] = Detection_Efficiency(calibSat, calibDia, calibDe, fitting, dia_cut, conc, sat_flow);

%Detection efficiency calculation and corresponding values at each cut off

%
%   calibSat = calibrational value of Saturator Flow Rate variable
%   calibDia = calibrational value of Diameter variable
%   calibDe = calibrational value of Detection Efficiency
%   Fitting = type of the fit (1: exp (default), 2: power, 3: polynomial (5 deg).)
%   dia_cut = Diameter size cut off
%   nro = 1: saturation flow rate vs. detection efficiency, 2: saturation 
%            flow rate vs. diameter, 3: diameter vs. saturation flow rate,
%            4: diameter vs. detection efficiency


disp(' ')
disp('===== Calculating detection efficiency =====')

% Turn off warning of curve fit (due to NaN from pre-treatment)
id = ['curvefit:fittype:sethandles:xMustBePositive'];
warning('off',id);

% Find fit

if fitting == 1 % exponential, 2nd deg  [y=a*exp(b*x)+c*exp(d*x)]
    ft1 = fit(calibSat, calibDia,'exp2');
    ft2 = fit(calibDia,calibDe,'exp2');
elseif fitting == 2 % power [f(x) = a*x^b+c]
    ft1 = fit(calibSat, calibDia,'power2');
    ft2 = fit(calibDia,calibDe,'power2');
elseif fitting == 3 % polynomial (5 deg)
    ft1 = fit(calibSat, calibDia,'poly5');
    ft2 = fit(calibDia,calibDe,'poly5');
elseif fitting == 4 % exp, 1st deg
    ft1 = fit(calibSat, calibDia,'exp1');
    ft2 = fit(calibDia,calibDe,'exp1');
elseif fitting == 5 % polynomial, 3rd deg
    ft1 = fit(calibSat, calibDia,'poly3');
    ft2 = fit(calibDia,calibDe,'poly3');
else
    errorMessage = sprintf('Detection Efficiency Error: Please enter a proper fitting type');
    uiwait(warndlg(errorMessage));
end

%interpolate diameter cutoff values to get corresponding y values
% y1 = ft1(sat_flow); % SFR vs diameter
% y2 = ft2(y1); % diameter vs Det eff

%% Obtain particle size from saturator flow rate

y1 = ft1(sat_flow); % Particle diameter
y2 = ft2(y1); % Detection efficiency
y3 = sat_flow;

%% Figure plots
% Fig 1: diameter vs SFR
% Fig 2: diameter vs Det eff


%% Plots
% Obtain particle size from saturator flow rate

figure(1)
movegui('northwest');
plot(ft1,calibSat,calibDia);
ylim([0 3]);
xlim([0 1.4]);
hold on
plot(sat_flow,y1,'k*');
xlabel( 'Saturation flow rate (lpm)' );
ylabel( 'Diameter (nm)' );
legend('raw data', 'fitted curve', 'fitted points', 'Location', 'NorthEast');
grid on
hold off
pause(0.5)


figure(2)
movegui('north');
plot(ft2,calibDia,calibDe,'.');
ylim([0 1]);
hold on
plot(y1,y2,'k*');
xlabel( 'Diameter (nm)' );
ylabel( 'Detection efficiency' );
legend('raw data', 'fitted curve', 'fitted points', 'Location', 'NorthEast');
grid on
hold off



