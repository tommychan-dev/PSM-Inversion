function dat_inv = Loss_Correction(dat_inv, dia, dia_cut, core_sampling);
%% Calculation of diffusion, penetration and core sampling losses
% ** Calculation of core sampling line loss takes considerable time
% Set 1 or 0 in main file


disp(' ')
disp('===== Loss correction =====')

%% Core sampling line losses correction and line downstream of the core sampling
% The cutpoint is the cutpoint, below which a fraction of the total flow enters
% the core sampling tube - and above that, it is discarded as the bypass flow
% (calculation Xue Mo, Tsinghua)

if core_sampling == 1

    load('eigenvalue.mat');%??

    for j=length(dia):-1:1

    L = 1.33; %tube length
    D = Diffuus(dia(j).*1e-9,293,101325);
    Q = 7.5*1.e-3/60; %total flow
    Qs = 2.5*1.e-3/60; %sample flow
    xi = Qs/Q;

    t_co = L*D*pi/2/Qs;
    t = t_co*xi;

    x = [0: 0.002: 1]';
    sx = size(x, 1);
    Uxt = zeros(sx, 1);

    for i = 1:sx
        Uxt(i) = CalcU(x(i), t, l);
    end

    cut_point=(1-(1-Qs./Q)^0.5).^0.5;
    ind=find(x<cut_point);

    penetration1(j)=trapz(x(ind),Uxt(ind).*2.*pi.*x(ind).*(1-x(ind).^2)) ...
        ./(2.*pi.*trapz(x(ind),x(ind).*(1-x(ind).^2)));

    end


    L2=0.2; %in m, tube length from core sampling piece to the psm mixing section
    penetration2=LTubeFl(dia.*1e-9,L2,2.5/60000,293,101325);
    for jj=1:length(penetration1);
    penetration(jj)=penetration1(jj).*penetration2(jj);
    end

        for i=1:size(dia,2)-1
            dat_inv(:,i)=dat_inv(:,i)./penetration(i);
        end

end

%% Diffusion losses correction - adapted from Lehtipalo 2014
% Calculates penetration ratio of particles with diameter d in a tube flow 
% of air as a carrier gas.

% Accounts for turbulent losses, both diffusional and inetrial.
% Plots the penetration efficiency against diameter and places it in variable
% penetration;
%
% d = particle diameter (vector) [m]
% Q_lpm = volumetric flow rate in [Liters per minute]
% inletr = Tube radius [cm]
% inletl = Tube length [cm]
% temp = temperature in [Kelvin]
% press = pressure in [Pascal]

if core_sampling == 2
    
    % Length of tube (in cm)
    inletl = 133; %
    % Radius of tube (in cm)
    inletr = 0.3;
    % Flow rate (in lpm)
    inletfr = 2.5;
    % Temperature (in Kelvin)
    temp = 293;
    % Pressure (in Pascal)
    press = 101325;

    % Convert units
    inletl = inletl * 1e-2;
    inletr = inletr * 1e-2;

    penetration=Loss_Calc_Lauri(dia_cut,inletfr,inletr,inletl,temp,press,0);
    
%     figure(3)
%     semilogx(dia,penetration,'ro-')
%     ylabel('Penetration efficiency')
%     xlabel('Diameter [nm]')

%     Save losses correction to dat_inv file
    for i=1:size(dia,2)-1
        dat_inv(:,i)=dat_inv(:,i)./penetration(i);
    end

end

