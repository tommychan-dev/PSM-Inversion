function [dat_inv, timenew_avg] = Invert_Kernel(conc, ave_inversion, pvm, inv_window, dia, y1, y2, y3, dia_cut, calibFile)
%Kernel mode inversion (adapted from Lauri 2017)

%% Preparation for Kernel calculation and inversion

% Import variables
time = conc(:,1);
tconc = conc(:,2);
partsize = conc(:,3);
satflow = conc(:,4);

% Set start of the inversion to begin at the middle of half scan
i_start_time = find(abs(satflow-0.11) < 0.05 | abs(satflow-1.29) < 0.05,1,'first');

% If time(i_start_time) > pvm+datenum(0,0,0,0,1,0)
start_time=time(i_start_time);

timenew_avg = start_time:ave_inversion/(60*24):pvm + 1;
% r = 0.1:inv_window:max(satflow);
r = y3;
lr = size(r,2);

% Pre-allocate
conc1b=ones(length(timenew_avg),lr-1);

for i=1:lr-1   
    k=find(satflow >= r(i) & satflow <= r(i+1) & start_time < time);
    time1=time(k);
    conc1=tconc(k);
    conc1b(:,i)=(Averaging_Time(time1,conc1,[timenew_avg],'median'));
    clear k time1 conc1
end

%% Differentiate concentration
% dconc=ones(length(timenew_avg),lr-2 ); % Pre-allocate

for i=1:lr-2
    dconc(:,i)=(conc1b(:,i+1)-conc1b(:,i));
end


% dconc=max(dconc,0); % To be determined for further use
stp = size(dia,2)-1;

for i=1:stp
     i_xs = (find(r >= y1(i),1,'first'));
     if i_xs < 1
        if ((abs( r(i_xs) - y1(i)) - abs(r(i_xs-1) - y1(i))) < 0)
            xs(i)=(i_xs-1);
        else
            xs(i)=(i_xs);
        end
     else        
         xs(i)=(i_xs);
     end
end

%% Calculating Gaussian-shaped inversion kernels
nrP = length(xs);
fitted_width = @(q1,p1,x) p1./(x + q1);

if max(satflow) > 1.10
    % Typical width while scanning 0.1 - 1.3
    w = fitted_width(-1.004845330847514,0.057949685534591,dia_cut)./(max(satflow)./length(1:lr-2));

else
    % Typical width while scanning 0.1 - 1
    w = fitted_width(-0.847359785344075,0.037844469977517,dia_cut)./(max(satflow)./length(1:lr-2));
end

w = normalize(w, 'range', [min(w(:)) min(w(:))]);

% Height of transfer function
for i = 1:size(w,2)
    h(i) = y2(i)/(sqrt(2*pi)*w(i));
end

xs = interp1(r,1:length(r), y1, 'linear', 'extrap');
xs = xs';
%% Creating kernels and plotting
kernel = Gauss_Dist(1:lr-2,[h,w,xs],nrP)';

eff = zeros(size(kernel,1), size(kernel,2)+1);
for ii = 1:size(eff,1)
    eff(ii,end) = y2(ii);
    for jj = 1:size(eff,2)-1
        eff(ii,jj) = y2(ii) - sum(kernel(ii,jj:end))*1;
    end
end
eff(eff < 0) = 0;

figure(4)
plot(w)
figure(5)
plot(h)
figure(6)
plot(r(2:end-1)',kernel')
figure(7)
plot(eff')
pause(0.5)

%% Least Squares Inversion calculation
for i=1:size(dconc,1)
    options = optimset('TolX',10*eps(1));
    dat_inv(i,:)=lsqnonneg(kernel',dconc(i,:)');
end