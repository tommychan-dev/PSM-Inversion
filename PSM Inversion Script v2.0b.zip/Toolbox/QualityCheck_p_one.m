%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Quality check scans via statistical hypothesis testing
% *** keeps scans if p-value < 0.05 and positive, otherwise NaN ***
% Several sections adapted from Airmodus Inversion v1.0
% Tommy Chan, Sept. 05th, 2018, Helsinki
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function conc = QualityCheck(conc);

% clear all
% close all

disp(' ')
disp('===== Pre-Treatment Quality Check =====')

%% Import data and prepare for quality check

time = conc(:,1);
totalconc = conc(:,2);
partsize = conc(:,3);
satflow = conc(:,4);

%% Search number of scans

if min(satflow) < 0.06
    flowmin = 0.05;
else
    flowmin = 0.1;
end
if max(satflow) > 1.2
    flowmax = 1.3;
else
    flowmax = 1;
end

k1 = find(round(100 .* satflow)./100 == flowmin);
k2 = min(k1);

k3 = find(round(100 .* satflow)./100 == flowmax);
k4 = min(k3);

k1_diff=diff(k1);
k3_diff=diff(k3);

idx=find(k1_diff>1);
start_low=k1(idx+1,1);
if idx(1)>1
    start_low=[k1(1); start_low];
end

mid_low=[];
for i=1:length(start_low);
    if i< length(start_low)
   idxx= find(k1 >=start_low(i) & k1 <start_low(i+1) );
   mid=idxx(round(numel(idxx)/2));
   mid_low(i,1)=k1(mid);
    elseif i== length(start_low)
   idxx= find(k1 >=start_low(i));
   mid=idxx(round(numel(idxx)/2));
   mid_low(i,1)=k1(mid);       
    end
end

idx=find(k3_diff>1);
start_high=k3(idx+1,1);
if idx(1)>1
    start_high=[k3(1); start_high];
end

mid_high=[];
for i=1:length(start_high);
    if i< length(start_high)
   idxx= find(k3>=start_high(i) & k3 <start_high(i+1) );
   mid=idxx(round(numel(idxx)/2));
   mid_high(i,1)=k3(mid);
    elseif i== length(start_high)
   idxx= find(k3 >=start_high(i));
   mid=idxx(round(numel(idxx)/2));
   mid_high(i,1)=k3(mid);       
    end
end
    
mid_scans=sort([mid_low ;mid_high]);

nscan=zeros(1,length(satflow));
for i = 1:length(mid_scans)
    if i < length(mid_scans)
    nscan(mid_scans(i):mid_scans(i+1))=nscan(mid_scans(i)-1)+1;
    else
     nscan(mid_scans(i):end)=nscan(mid_scans(i)-1)+1;
    end
end
        

if isempty(nscan)
    disp('No scans found in the data file')
    return
end

% clearvars -except nscan tim totalconc satflow
nscan = nscan' + 1;

fprintf(1, 'Total number of scans: %d\n', max(nscan));

%% Check the quality of each scan

conc1 = [totalconc nscan];

Scan = [];

for i = 1:max(nscan)
    Nfind = find(nscan == i);
    slopeSatFlow = satflow(Nfind);
    slopeN = totalconc(Nfind);
    
    [slope,pval] = corr(slopeSatFlow, slopeN);
    Scan(i,:) = [i, pval(1), slope(1)];
  
%% Shows plot of each individual scan

%     f1 = figure(1);
%     if mod(i, 2) == 1
%         plot(slopeSatFlow,slopeN, '.k','markers',12) 
%         plotTitle1 = num2str(pval(1),3);
%         plotTitle2 = num2str(slope(1),3);
%         plotTitle3 = num2str(i);
% %        title({'pval: ' plotTitle1; 'rho: ' plotTitle2})
%         title({plotTitle3})
%         xlabel('Saturator flow rate (lpm)','Fontweight','bold')
%         ylabel('Concentration (cm^{-3})','Fontweight','bold')
%         hold on
%         slopeSatFlowSum = slopeSatFlow;
%         slopeNSum = slopeN;
%     else
%         plot(slopeSatFlow,slopeN, '.b','markers',12) 
%         plotTitle1 = num2str(pval(1),3);
%         plotTitle2 = num2str(slope(1),3);
%         plotTitle3 = num2str(i/2);
%     %     title({'pval: ' plotTitle1; 'rho: ' plotTitle2})
%         title({plotTitle3})
%         xlabel('Saturator flow rate (lpm)','Fontweight','bold')
%         ylabel('Concentration (cm^{-3})','Fontweight','bold')
%         
%         slopeSatFlowSum = [slopeSatFlowSum; slopeSatFlow];
%         slopeNSum = [slopeNSum; slopeN];
%         
%         p = polyfit(slopeSatFlowSum,slopeNSum,1);
%         f = polyval(p,slopeSatFlowSum);
%         
%         plot(slopeSatFlowSum,f,'-r')
%         set(gca,'FontSize',12)
% 
%         DatFolder = 'C:\LocalData\tchan\[Work]\Kumpula\Manuscripts\PSM Inversion\[Data]\Data-bak\scan_data\saved\';
%         print(f1,'-dpng','-r200', [DatFolder,'Scan_',plotTitle3,'.png'])
%         clf(1)
%     end
% %     pause(2)
  
end

% Plot whole day scan vs slope with visual indicator of good and bad scans
aboveLine2 = (Scan(:,2) < 0.05);
bottomLine = Scan(:,2);
topLine = Scan(:,2);
bottomLine(aboveLine2) = NaN;
topLine(~aboveLine2) = NaN;

figure(1)
f1 = figure(1);
movegui('northwest');
plot(Scan(:,1),bottomLine,'.r', Scan(:,1),topLine,'.k')
title('Quality Scan Check')
xlabel('Scan number')
ylabel('p-value')
xlim([0 length(Scan)])
ylim([-0.2 1])
legend('Discarded Scan','Retained Scan')

%% NaN scans which have negative slope

goodScan = find(Scan(:,3) > 0 & Scan(:,2) < 0.05);
medScan = find(Scan(:,3) > 0 & Scan(:,2) > 0.01 & Scan(:,2) < 0.05); % Used to see which scans are if between 0.01 and 0.05
badScan = Scan(~(aboveLine2));

badScanC2 = [];

for i = 1:length(badScan)
    badScanC = find(nscan == badScan(i,1));
    badScanC2 = [badScanC2; badScanC];
end

totalconc(badScanC2) = NaN;
partsize(badScanC2) = NaN;
satflow(badScanC2) = NaN;

goodResult = (sum(aboveLine2));
badResult = length(Scan) - goodResult;

fprintf(1, 'Total number of retained scans: %d\n', goodResult);
fprintf(1, 'Total number of discarded scans: %d\n', badResult);

% Create new file and export to main script
conc = [time totalconc partsize satflow];

pause(0.5)