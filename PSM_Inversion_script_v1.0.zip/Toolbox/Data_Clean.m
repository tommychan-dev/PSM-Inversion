function conc = Data_Clean(conc, psm, pre_filtering, pre_method, window_pre);
%Cleaning raw data for noise and background measurements

disp(' ')
disp('===== Cleaning raw data for noise =====')

%% Fudan CPC gap correction

if psm == 2

   conc = CPC_Gap(conc); 
    
end

%% Remove background measurements

% Planned in future update

%% Smooth data for noise correction

if (pre_filtering == 1)
    
conc_filt = conc(:,2);

    if pre_method == string('moving')
            conc_filt=smooth(conc_filt,window_pre,'moving');
    elseif pre_method == string('loess')       
            conc_filt=smooth(conc_filt,window_pre,'loess');
    else
            conc_filt=smooth(conc_filt,window_pre,pre_method);
    end
    
conc(:,2) = conc_filt;    

end