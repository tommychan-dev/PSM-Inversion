x = [0: 0.1: 20]';
n = size(x, 1);
y1 = zeros(n, 1);
y2 = zeros(n, 1);

f = @(x) MPoly(1, 1, x, 10);

for i = 1:n
    y1(i) = exp(x(i));
    y2(i) = f(x(i));
end

f = @(l) MPoly(0.5 - 0.25*l, 1, l, 200);
fzero(f, 75);