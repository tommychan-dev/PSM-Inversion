function [Rb] = getRb(u, p)

su = size(u, 1);
u_norm = u/u(1);

for i = 1:su
    if (p > u_norm(i))
        idx = i;
        break;
    end
end

Rb = (p - u_norm(idx-1))/(u_norm(idx) - u_norm(idx -1));
Rb = Rb + idx - 1;
Rb = (Rb - 1)*1.0/(su - 1);

end