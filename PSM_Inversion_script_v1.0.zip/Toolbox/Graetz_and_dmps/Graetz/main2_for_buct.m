clear all
load('eigenvalue.mat');%??

%dp=[1.3 1.7 2.1 2.8].*1e-9;
dp=[2.25 1.85 1.55 1.3];
for j=1:length(dp)

L = 1.33; %tube length/m
D = diffuus(dp(j),293,101325);
Q = 7.5*1.e-3/60; %total flow of fudan,for BUCT,5.25
Qs = 2.5*1.e-3/60; %sample flow
xi = Qs/Q;

t_co = L*D*pi/2/Qs;
t = t_co*xi;

x = [0: 0.002: 1]';
sx = size(x, 1);
Uxt = zeros(sx, 1);

for i = 1:sx
    Uxt(i) = CalcU(x(i), t, l);
end

plot(x, Uxt);
hold all
cut_point=(1-(1-Qs./Q)^0.5).^0.5;
ind=find(x<cut_point);

penetration1(j)=trapz(x(ind),Uxt(ind).*2.*pi.*x(ind))./(pi.*cut_point.^2);

end

L2=0.2; %in m, tube length from core sampling piece to the psm mixing section
penetration2=ltubefl(dp,L2,2.5/60000,293,101325);
penetration=penetration1*penetration2

figure,plot(dp,penetration1.*penetration2,dp,penetration1,dp,penetration2)
legend('total','sampling + core sampling','downstream of core sampling')
