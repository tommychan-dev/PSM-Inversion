function [Q_opt, xi_opt] = OptQ(L, D, R, Qs, p, tol_in)

tol = 1.e-10;
if nargin >= 6
    tol = tol_in;
end

n = 1000;

load('eigenvalue.mat');
sl = size(l, 1);

x = [0:0.02:1]';
sx = size(x, 1);

XM = zeros(sx, sl);
for i = 1:sl
    l_curr = l(i);
    for j = 1:sx
        XM(j, i) = Graetz(x(j), l_curr, n);
    end
end

t_co = L*D*pi/Qs/2.0;

xi = 1;
xi_ub = xi;

while(1)
    Rs = sqrt(1 - sqrt(1 - xi));
    
    t = t_co*xi;
    Et = exp(-l.^2*t);
    AE = A.*Et;
    u = XM*AE;
    Rb = getRb(u, p);
    
%     [Rs, Rb]
    
    if (Rs < Rb)
        xi_lb = xi;
        break;
    end
    
    if (Rs > Rb)
        xi_ub = xi;
    end
    
    xi = xi*0.5;
end

% [xi_lb, xi_ub]

xi_l = xi_lb;
xi_u = xi_ub;

while(1)
    
    if (xi_u - xi_l < tol)
        xi_opt = 0.5*(xi_u + xi_l);
        break;
    end
    
    xi_m = 0.5*(xi_l + xi_u);
    
    Rs = sqrt(1 - sqrt(1 - xi_m));
    
    t = t_co*xi_m;
    Et = exp(-l.^2*t);
    AE = A.*Et;
    u = XM*AE;
    Rb = getRb(u, p);
    
    if (Rs < Rb)
        xi_l = xi_m;
    else
        xi_u = xi_m;
    end
    
end

Q_opt = Qs/xi_opt;

end