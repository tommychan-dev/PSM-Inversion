load('eigenvalue.mat');

L = 1;
D = 2.37e-6;
Q = 8*1.e-3/60;
Qs = 2*1.e-3/60;
xi = Qs/Q;

t_co = L*D*pi/2/Qs;
t = t_co*xi;

x = [0: 0.002: 1]';
sx = size(x, 1);
Uxt = zeros(sx, 1);

for i = 1:sx
    Uxt(i) = CalcU(x(i), t, l);
end

plot(x, Uxt);