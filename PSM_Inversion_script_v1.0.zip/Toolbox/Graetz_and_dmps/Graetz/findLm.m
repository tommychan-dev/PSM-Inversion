function [lm] = findLm(lb, ub, n_in, tol_in)

n = 200;
if nargin >= 3
    n = n_in;
end

tol = 0.25*1.e-13;
if nargin >= 4
    tol = tol_in;
end

f = @(l) MPoly(0.5 - 0.25*l, 1, l, n);

lower = lb;
upper = ub;

fl = f(lower);
fu = f(upper);

label = 1;
if (fl < 0)
    label = 0;
end

if (label == 1)
    while(1)
        if ((upper - lower) < tol)
            lm = (lower + upper)*0.5;
            break;
        end
        
        middle = (lower + upper)*0.5;
        fm = f(middle);
%         [fl, fm, fu]
%         [lower, middle, upper]
%         upper - lower
        
        if (fm < 0)
            upper = middle;
            fu = fm;
        else
            lower = middle;
            fl = fm;
        end
    end
else
    while(1)
        if ((upper - lower) < tol)
            lm = (lower + upper)*0.5;
            break;
        end
        
        middle = (lower + upper)*0.5;
        fm = f(middle);
        
        if (fm < 0)
            lower = middle;
            fl = fm;
        else
            upper = middle;
            fu = fm;
        end
    end
end

end

