function [Uxt] = CalcU(x, t, l)

sl = size(l, 1);
A = zeros(sl, 1);
Gzx = zeros(sl, 1);
Et = zeros(sl, 1);

k = 50;
n = 1000;

for i = 1:sl
    A(i) = CalcAm(l(i), k, n);
    Gzx(i) = Graetz(x, l(i), n);
    Et(i) = exp(-l(i)^2*t);
end

Xx = A.*Gzx;
Uxt = Xx'*Et;

end