function k=kaasuv()
k=8.3143;

