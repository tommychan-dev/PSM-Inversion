function e=eo()
e=8.854e-12;

