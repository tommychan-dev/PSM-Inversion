function vv=visc(t)
vv=(174.+0.433*(t-273.))*1.0e-7;
