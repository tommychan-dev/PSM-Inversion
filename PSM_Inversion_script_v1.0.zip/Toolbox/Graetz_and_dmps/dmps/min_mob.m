function tulos=min_mob(mob,t,press)


dp=1e-9*ones(length(mob),1);


dpt=ones(length(mob),1);

while max(abs(dp-dpt) ./dpt) > 1e-6
dp=dpt;
dpt=e*cunn(dp,t,press) ./(3*pi*visc(t)*mob);
end

tulos=dpt;

