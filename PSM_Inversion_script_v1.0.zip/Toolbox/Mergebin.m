%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Merge bins
% Runlong Cai, Nov. 23th, 2017, Helsinki
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function b = mergebin(x,y,a)
% x,a increase monotonously
% length(x)>length(b)
% length(x) = length(y)+1
% length(a) = length(b)+1

b = zeros(1,length(a)-1);
for i = 1:length(a)-1
    for j = 1:length(x)-1
        if x(j+1) < a(i)
            continue;
        elseif x(j) < a(i)
            b(i) = b(i) + y(j) * (x(j+1)-a(i))/(x(j+1)-x(j));
        elseif x(j+1) < a(i+1)
            b(i) = b(i) + y(j);
        elseif x(j) < a(i+1)
            b(i) = b(i) + y(j) * (a(i+1)-x(j))/(x(j+1)-x(j));
        else
            break;
        end
    end
end

end
            
            