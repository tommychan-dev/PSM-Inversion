function dat_inv = Loss_Correction(dat_inv, dia, dia_cut, core_sampling);
%% Calculation of diffusion, penetration and core sampling losses
% ** Calculation of core sampling line loss takes considerable time
% Set 1 or 0 in main file


disp(' ')
disp('===== Loss correction =====')

%% Core sampling line losses correction and line downstream of the core sampling
% The cutpoint is the cutpoint, below which a fraction of the total flow enters
% the core sampling tube - and above that, it is discarded as the bypass flow
% (calculation Xue Mo, Tsinghua)

if core_sampling == 1
% 
%     A = [1.47647767648665;-0.806525189579587;0.588615907620550;-0.476572726540577;0.404651244527603;-0.356783220670338;0.318562706268510;-0.292060343064381;0.267042515933629;-0.250681711078320;0.232132148433197;-0.221603958626865;0.206615967722206;-0.199888750089486;0.186986032716083;-0.182968655809246;0.171314512728374;-0.169365805409338;0.158446647110610;-0.158164369279362;0.147644820092178;-0.148763935282184;0.138414232216991;-0.140751660068288;0.130408047286049;-0.133854306058621;0.123428428976774;-0.128229202351612];
%     l = [2.70436441988253;6.67903144934663;10.6733795380537;14.6710784627362;18.6698718644512;22.6691433588373;26.6686619960115;30.6683233409175;34.6680738224338;38.6678833468598;42.6677338055420;46.6676136978162;50.6675153950972;54.6674336526801;58.6673647548702;62.6673060011076;66.6672553849655;70.6672113869111;74.6671728366291;78.6671388192378;82.6671086099772;86.6670816278141;90.6670574018960;94.6670355469399;98.6670157448244;102.666997730770;106.666981282775;110.666966213382];
% 
%     dia=dia.*1e-9;
% 
%     for j=1:length(dia)
%         L = 1.33; %BUCT tube length in meters
%         D = diffuus(dia(j),293,101325);
%         Q = 7.5*1.e-3/60; %total flow
%         Qs = 2.5*1.e-3/60; %sample flow
%         xi = Qs/Q;
% 
%         t_co = L*D*pi/2/Qs;
%         t = t_co*xi;
% 
%         x = [0: 0.002: 1]';
%         sx = size(x, 1);
%         Uxt = zeros(sx, 1);
% 
%         for i = 1:sx
%             Uxt(i) = CalcU(x(i), t, l);
%         end
% 
%         cut_point=(1-(1-Qs./Q)^0.5).^0.5;
%         ind=find(x<cut_point);
% 
%         % Penetration loss that includes velocity profile
%         penetration1(j)=trapz(x(ind),Uxt(ind).*2.*pi.*x(ind).*(1-x(ind).^2)) ...
%             ./(2.*pi.*trapz(x(ind),x(ind).*(1-x(ind).^2)));
%     end
% 
%     L2=0.2; %in m, tube length from core sampling piece to the psm mixing section
%     penetration2=ltubefl(dia_cut,L2,2.5/60000,293,101325);
% 
% %     figure(3)
% %     plot(dia,penetration1.*penetration2,dia,penetration1,dia,penetration2)
% %     legend('total','sampling + core sampling','downstream of core sampling')
% 
%     % Record total penetration losses to dat_inv
%     for jj=1:length(penetration1);
%         penetration(jj)=penetration1(jj).*penetration2(jj);
%     end
%     
%     for i=1:size(dia,2)-1
%         dat_inv(:,i)=dat_inv(:,i)./penetration(i);
%     end
% 
% end
% 
% clc

load('eigenvalue.mat');%??

for j=length(dia):-1:1

L = 1.33; %tube length
D = Diffuus(dia(j).*1e-9,293,101325);
Q = 7.5*1.e-3/60; %total flow
Qs = 2.5*1.e-3/60; %sample flow
xi = Qs/Q;

t_co = L*D*pi/2/Qs;
t = t_co*xi;

x = [0: 0.002: 1]';
sx = size(x, 1);
Uxt = zeros(sx, 1);

for i = 1:sx
    Uxt(i) = CalcU(x(i), t, l);
end

cut_point=(1-(1-Qs./Q)^0.5).^0.5;
ind=find(x<cut_point);

penetration1(j)=trapz(x(ind),Uxt(ind).*2.*pi.*x(ind).*(1-x(ind).^2)) ...
    ./(2.*pi.*trapz(x(ind),x(ind).*(1-x(ind).^2)));

end


L2=0.2; %in m, tube length from core sampling piece to the psm mixing section
penetration2=LTubeFl(dia.*1e-9,L2,2.5/60000,293,101325);
for jj=1:length(penetration1);
penetration(jj)=penetration1(jj).*penetration2(jj);
end

    for i=1:size(dia,2)-1
        dat_inv(:,i)=dat_inv(:,i)./penetration(i);
    end

end

%% Diffusion losses correction - adapted from Lehtipalo 2014
% Calculates penetration ratio of particles with diameter d in a tube flow 
% of air as a carrier gas.

% Accounts for turbulent losses, both diffusional and inetrial.
% Plots the penetration efficiency against diameter and places it in variable
% penetration;
%
% d = particle diameter (vector) [m]
% Q_lpm = volumetric flow rate in [Liters per minute]
% inletr = Tube radius [cm]
% inletl = Tube length [cm]
% temp = temperature in [Kelvin]
% press = pressure in [Pascal]

if core_sampling == 2
    
    % Length of tube (in cm)
    inletl = 133; %BUCT value
    % Radius of tube (in cm)
    inletr = 0.3;
    % Flow rate (in lpm)
    inletfr = 2.5;
    % Temperature (in Kelvin)
    temp = 293;
    % Pressure (in Pascal)
    press = 101325;

    % Convert units
    inletl = inletl * 1e-2;
    inletr = inletr * 1e-2;

    penetration=Loss_Calc_Lauri(dia_cut,inletfr,inletr,inletl,temp,press,0);
    
%     figure(3)
%     semilogx(dia,penetration,'ro-')
%     ylabel('Penetration efficiency')
%     xlabel('Diameter [nm]')

%     Save losses correction to dat_inv file
    for i=1:size(dia,2)-1
        dat_inv(:,i)=dat_inv(:,i)./penetration(i);
    end

%     for i = 1:length(conc(:,2))
%         if conc(i,3) < dia(1) & conc(i,3) > dia(2)
%             conc(i,2) = conc(i,2)./penetration(1);
%         elseif conc(i,3) < dia(2) & conc(i,3) > dia(3)
%             conc(i,2) = conc(i,2)./penetration(2);
%         elseif conc(i,3) < dia(3) & conc(i,3) > dia(4)
%             conc(i,2) = conc(i,2)./penetration(3);
%         elseif conc(i,3) < dia(4) & conc(i,3) > dia(5)
%             conc(i,2) = conc(i,2)./penetration(4);
%         end
%     end
    
end

