function Inversion_Comp_Scan(baseFileName, fullFileName, wanttosave, savingpath, path_calib, dia, fitting, psm, pre_filtering, pre_method, window_pre, method, core_sampling, mode, qualitycheck, diluter, dilution, post_filtering)
%% Script to compare four inversion methods (step-wise, kernel, HA and EM)
% Author: Tommy Chan (tommy.chan@helsinki.fi)
% Date: 2019.11.28

%% Data management

tic

% Load the data, skip first row
fid = fopen([fullFileName]);
header = ['%s ' repmat('%f ',1,42) repmat('%s ',1,4)];
% header = ['%s ' repmat('%f ',1,19) repmat('%s ',1,3)]; % for tsi CPC
data = textscan(fid,header,'Headerlines',1,'Delimiter',',');
fclose(fid);

% Define time and remaining columns
% *time finds min and max for plotting whole day
time=datenum(data{1},'dd.mm.yyyy HH:MM:SS');
timemin = min([time]);
timemax = round(max([time]),0);
date_select=datestr(time(1,1),'yyyymmdd');

totalconc = data{2};
partsize = data{3};
satflow = data{4};

conc = [time totalconc partsize satflow];

% Time settings
date_select = datestr(time(1,1),'yyyymmdd');
pvm = datenum(date_select,'yyyymmdd');
startt = '00:00';
endt = '24:00';
starttime = pvm + datenum(['0,0,0,',startt],15);
endtime = pvm + datenum(['0,0,0,',endt],15);

% Averaging for the inversion
ave_inversion = 4; %4 minutes before inversion
inv_window = 0.06; %0.06 (of saturator flow rate)
ave = 12;          %12 minutes after inversion (can be 8)

% Diameter size cut off
for i=1:length(dia)-1
    dia_cut(i) = mean([dia(i),dia(i+1)]);
end

% Define calibration file
calibFile = load(path_calib);
calibSat=calibFile(:,1);
calibDia=calibFile(:,2);
calibDe=calibFile(:,3);

% Identify saving parameters
[fileid1, fileid2, fileid3] = Save_ID(psm, mode, method);

%% Pre-treatment of raw data
% Function to check quality of scan and removes scan (NaN)
% if slope of N/Nmax (per scan) is less than or equal to 0

if qualitycheck == 1
    conc = QualityCheck_p(conc);
end

%% Data cleaning

% Clean data for fudan gap correction, background measurements and noise
% with output file as conc

conc = Data_Clean(conc, psm, pre_filtering, pre_method, window_pre);

table = [conc];
dlmwrite([savingpath,date_select,'_',fileid1,'_',fileid2,'_raw.dat'],table,...
    'precision','%10.10f','newline','pc','delimiter','\t')

%% Detection efficiency curve calculation

% Retrieve y1 and y2 from calculation based on predefined diameter sizes
% y1 = corresponding sat flow, y2 = corresponding det eff
% y3 = correspsonding particle size from sat flow rate
% *see Figure 1 and 2

[y1, y2, y3] = Detection_Efficiency(calibSat, calibDia, calibDe, fitting, dia_cut, conc);

%% Inversion Method

disp(' ')
disp('===== Inverting =====')

if method == 1 % Step-wise (Lehtipalo 2014)
    [dat_inv, timenew_avg] = Invert_Stepwise_AM(conc, dia, y1, y2, y3, dia_cut, calibFile);
elseif method == 2 % Kernel (Ahonen 2017, adapted from Lehtipalo 2014)
    [dat_inv, timenew_avg] = Invert_Kernel(conc, ave_inversion, pvm, inv_window, dia, y1, y2, y3, dia_cut, calibFile);
elseif method == 3 % Hagen and Alofs (Runlong 2018)
    [dat_inv, timenew_avg] = Invert_HA(conc, ave_inversion, pvm, inv_window, dia, y1, calibFile);
elseif method == 4 % Expectation-maximization algorithm (Runlong 2018)
    [dat_inv, timenew_avg] = Invert_EM(conc, ave_inversion, pvm, inv_window, dia, calibFile, dia_cut);
else
    errorMessage = sprintf('Inversion Method Error: Please enter a proper inversion method');
    uiwait(warndlg(errorMessage));
end

%% Calculate diffusion losses and core sampling losses
% Two methods used: Xue Mo (Tsinghua) and Lehtipalo 2014.
% Generally, both outputs are the same i.e., ratios between them are 1:1
% However, absolute values are different - larger in Lehtipalo 2014

if core_sampling > 0
    dat_inv = Loss_Correction(dat_inv, dia, dia_cut, core_sampling);
end

%Include dilution factor 
if diluter == 1  
    dat_inv = dat_inv(:,:) * dilution;
end
    
%% Convert data to longer averaging time and smoothing

conc3 = dat_inv;

if post_filtering == 1
    timenew2 = [starttime:ave/(60*24):endtime];

    if ave > ave_inversion
        conc3 = Averaging_Time(timenew_avg, dat_inv, timenew2, 'mean');
    else
        for k = 1:size(dia,2)-1
            conc3(:,k)=smooth(conc3(:,k),window_pre,pre_method);
        end
    end

    for i = 1:length(dia_cut)
%         conc3(:,i) = medfilt1(movmean(conc3(:,i),10),3); %Tommy
        conc3(:,i) = smooth(conc3(:,i),'lowess',3); % Dongsen
    end
end

%% Change concentration to dN/dlogdp units

for i=1:size(dia,2)-1
    dlogdp(i) = log10(dia(i)*1e-9)-log10(dia(i+1)*1e-9);
    conc4(:,i) = conc3(:,i)./dlogdp(i);
end

%% Saving data
% File name identifier for inverted data (save file) PSM's .dat file

disp(' ')
disp('===== Plotting and saving data =====')

[fileid1, fileid2, fileid3] = Save_ID(psm, mode, method);

if wanttosave == 1
    if post_filtering == 1 
        table = [dia; transpose(timenew2) conc3];
        dlmwrite([savingpath,date_select,'_',fileid1,'_',fileid2,'_',fileid3,'.dat'],table,...
            'precision','%10.10f','newline','pc','delimiter','\t')

        table = [dia; transpose(timenew2) conc4];
        dlmwrite([savingpath,date_select,'_',fileid1,'_',fileid2,'_',fileid3,'_dlog.dat'],table,...
            'precision','%10.10f','newline','pc','delimiter','\t')
    else
        table = [dia; transpose(timenew_avg) conc3];
        dlmwrite([savingpath,date_select,'_',fileid1,'_',fileid2,'_',fileid3,'.dat'],table,...
            'precision','%10.10f','newline','pc','delimiter','\t')

        table = [dia; transpose(timenew_avg) conc4];
        dlmwrite([savingpath,date_select,'_',fileid1,'_',fileid2,'_',fileid3,'_dlog.dat'],table,...
            'precision','%10.10f','newline','pc','delimiter','\t') 
    end
end

%% Plotting Time Series Data

%Determine which psm and method for figure
if psm == 1
    psm = 'BUCT';
    elseif psm == 2 
        psm = 'Fudan';
    else
        psm = 'Other';
end

if method == 1
    method = 'Step-wise';
    elseif method == 2 
        method = 'Kernel';
    elseif method == 3 
        method = 'H&A';
    elseif method == 4 
        method = 'EM';        
end
    
% Define concentration range for all figures
upperlimit = ceil(max(dat_inv(:)));
upperlimit = 10000*(ceil(upperlimit/10000.));
upperlimit = 10e5;
lowerlimit=10;

font_name='cambria';
fontsize=12;
fontsize_axis=12;

% Rounding diameters
dround=round(dia,3,'significant');
dround_cut=round(dia_cut,3,'significant');

cc=lines(length(dia));

f1 = figure(9);

h = ones(1,size(dia,2)-1);

if post_filtering == 1
    for k = 1:size(dia,2)-1
        dr = [num2str(dround(k+1)),'-',num2str(dround(k)),' nm'];
        h(k) = plot(timenew2,conc3(:,k),'-', ...
        'DisplayName', sprintf(dr, k),'linewidth',1.5,'color',cc(k,:));
        hold all
    end
else
    for k = 1:size(dia,2)-1
        dr = [num2str(dround(k+1)),'-',num2str(dround(k)),' nm'];
        h(k) = plot(timenew_avg,conc3(:,k),'-', ...
        'DisplayName', sprintf(dr, k),'linewidth',1.5,'color',cc(k,:));
        hold all
    end
end

hh=  legend(h); 
movegui('northwest');
set(hh,'fontname',font_name)
set(gca,'xtick',[pvm pvm+0.25 pvm+0.5 pvm+0.75 pvm+1])
datetick('x','keepticks')
ylim([lowerlimit upperlimit])
xlabel('Time [hh:mm]','Fontweight','normal','fontsize',fontsize,'fontname',font_name);
ylabel('Concentration [cm^{-3}]','Fontweight','normal','fontsize',fontsize,'fontname',font_name);
title(['Concentration in size classes', ' - ', date_select, ' - ', method],'Fontweight','normal','fontsize',fontsize,'fontname',font_name)
% title(['Concentration in size classes'],'Fontweight','normal','fontsize',fontsize,'fontname',font_name)
set(gca,'fontsize',fontsize_axis,'linewidth',1.5,'fontname',font_name)

set(gca,'yscale','log')

if wanttosave==1;
    print(f1,'-dpng','-r200', [savingpath,date_select,'_',fileid1,'_',fileid2,'_',fileid3,'_TimeSeries.png'])
end

%% Surface Plotting

dmin = min(dia);
dmax = max(dia);

% Find plotting range for concentration
concmin = floor(log10(lowerlimit));
concmax = ceil(log10(upperlimit));
ticks=[];

for s=concmin:concmax;
    tick=10^(s);
    ticks=[ticks tick];
end

f2 = figure(10);
colormap jet
conc5=max(conc4,0.00001);
z=log10(conc5);
z=[z ones(size(z,1),1)];

if post_filtering == 1
    pcolor(timenew2',dia',z')
else
    pcolor(timenew_avg',dia',z')
end

caxis([concmin concmax])
gcc=colorbar('horiz');
set(gcc,'linewidth',1)
set(gcc,'fontsize',12)
xlabel(gcc,'dN / dlog Dp (1/cm^3)')
grid off
set(gca,'ylim',[dmin dmax])
set(gca,'yscale','log')
set(gca,'fontsize',12)
set(gca,'fontname',font_name)
set(gca,'ytick',fliplr(dround))


movegui('northeast');
ylabel('Particle diameter [nm]','Fontsize',fontsize,'fontname',font_name)
xlabel('Time','fontsize',fontsize,'fontname',font_name)
set(gca,'xtick',[pvm pvm+0.25 pvm+0.5 pvm+0.75 pvm+1])
datetick('x','keepticks')
title(['Size distribution', ' - ', date_select, ' - ', method],'Fontweight','normal','fontsize',fontsize)
shading flat 
set(gca,'fontsize',fontsize_axis,'linewidth',1.5)
set(gca,'layer','top')

if wanttosave==1;
    print(f2,'-dpng','-r200', [savingpath,date_select,'_',fileid1,'_',fileid2,'_',fileid3,'_Surface.png'])
end

disp(' ')
disp('===== Inversion complete =====')
disp(' ')

toc;
timeElapsed = toc;
disp(' ')