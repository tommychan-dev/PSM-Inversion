% function Inversion_Comp_Step(baseFileName, fullFileName, wanttosave, savingpath, path_calib, dia, fitting, psm, pre_filtering, pre_method, window_pre, method, core_sampling, mode);

%Tommy Chan - 2018.03.13

%Course of action, load data
%removed peaks and smoothed data (moving average filter)

%Derived from Lehtipalo 2014
%% Data to be removed in final version

clear all
close all

% Enter data directory *place all raw PSM dat to be analyzed
DatFolder = 'D:\[Documents]\BUCT\PSM\Matlab Scripts\Compare Inversion\[Data]\';

% Enter saving directory
paths.save='D:\[Documents]\BUCT\PSM\Matlab Scripts\Compare Inversion\[Data]\Save\';

% Enter calibration file
path_calib ='D:\[Documents]\BUCT\PSM\Matlab Scripts\BUCT Inversion\A1113080113_NiCr_CF_170224.txt';

% Enter inversion method
% (1: Step-wise, 2: Kernel, 3: Hagen and Alofs, 4: Expectation-maximization algorithm)
method = 1;

% Enter PSM instrument
% (1: buct, 2: fudan)
psm = 2;

% Enter PSM data recording mode
% (1: scanning, 2: stepping)
mode = 1;

% Saving (1/0; on/off)
wanttosave = 1; %( figures are saved ONLY if plotting)

% Smoothen raw data (1/0; on/off)
pre_filtering = 1  ; 
pre_method = 'loess'; % 'loess' | 'moving' - loess or moving average
window_pre = 12; % span of the filtering

% Fitting model profile for calibration file
% (1: exponential (2nd deg), 2: power, 3: polynomial (5 deg), 4: exponential (1st deg)
fitting = 2;

% Enter diameter size bins
dia = [2.6 2.2 1.8 1.5 1.3];

% Core sampling line losses correction (1/2; Xue Mo/Lehtipalo 2014 versions)
% ** Xue Mo version takes considerable time
core_sampling = 2;

if wanttosave==1
    savingpath=paths.save;
    if exist(savingpath,'dir') == 0
        mkdir(savingpath)
    end
end

if ~isdir(DatFolder)
  errorMessage = sprintf('Error: The following folder does not exist:\n%s', DatFolder);
  uiwait(warndlg(errorMessage));
  return;
end

filePattern = fullfile(DatFolder, '*.dat');
datFiles = dir(filePattern);
for i = 1:length(datFiles)
    baseFileName = datFiles(i).name;
    fullFileName = fullfile(DatFolder, baseFileName);
    fprintf(1, 'Now reading %s\n', fullFileName);
end

path_calib ='D:\[Documents]\BUCT\PSM\Matlab Scripts\BUCT Inversion\A1113080113_NiCr_CF_170224.txt';


%% Data management

% Load the data, skip first row
fid = fopen([fullFileName]);
header = ['%s ' repmat('%f ',1,42) repmat('%s ',1,4)];
data = textscan(fid,header,'Headerlines',1,'Delimiter',',');
fclose(fid)

% Define time and remaining columns
% *time finds min and max for plotting whole day
time=datenum(data{1},'dd.mm.yyyy HH:MM:SS');
timemin = min([time]);
timemax = round(max([time]),0);
date_select=datestr(time(1,1),'yyyymmdd');

totalconc = data{2};
partsize = data{3};
satflow = data{4};

conc = [time totalconc partsize satflow];

% Time settings
date_select = datestr(time(1,1),'yyyymmdd');
pvm = datenum(date_select,'yyyymmdd');
startt = '00:00';
endt = '24:00';
starttime = pvm + datenum(['0,0,0,',startt],15);
endtime = pvm + datenum(['0,0,0,',endt],15);

% Diameter size cut-off
for i=1:length(dia)-1
    dia_cut(i) = mean([dia(i),dia(i+1)]);
end

% Define calibration file
calibFile = load(path_calib);
calibSat=calibFile(:,1);
calibDia=calibFile(:,2);
calibDe=calibFile(:,3);

%% Data cleaning

%Clean data for fudan gap correction, background measurements and noise
%with output file as conc

conc = Data_Clean(conc, psm, pre_filtering, pre_method, window_pre);

%% Detection efficiency curve calculation

% Retrieve y1 and y2 from calculation based on predefined diameter sizes
% y1 = corresponding sat flow, y2 = corresponding det eff
% *see Figure 1 and 2

[y1, y2] = Detection_Efficiency(calibSat, calibDia, calibDe, fitting, dia_cut);

%% Step-wise inversion based on Lehtipalo 2014
%

% dat_inv = Invert_Stepwise(conc, dia_cut);

% Parition diameter sizes into cut-off diameters
for i = 1:length(conc)
    if  conc(i,3) < dia(1) & conc(i,3) > dia(2);
        conc(i,3) = dia_cut(1);
    elseif conc(i,3) < dia(2) & conc(i,3) > dia(3);
       conc(i,3) = dia_cut(2);
    elseif conc(i,3) < dia(3) & conc(i,3) > dia(4);
       conc(i,3) = dia_cut(3);
    elseif conc(i,3) < dia(4) & conc(i,3) > dia(5);
       conc(i,3) = dia_cut(4);
    else
       conc(i,3) = 4;
    end
end

% Delete rows until beginning of scan (smallest size bin)
ii = find(conc(:,3) == dia_cut(4));
conc = conc(ii(1):end,:);

% Find median values of each step
med_val = [];

% Start at first row
ii = conc(1,:);

for i = 2:length(conc)
    if abs(conc(i,3) - conc(i-1,3)) < 0.05
        ii = [ii;conc(i,:)];
    else
        if size(ii,1) > 0
            med_val = [med_val;median(ii(1:end,:),1)];
            ii = conc(i,:);
        end
    end
end

%% Inversion calculation

close all
dat_inv = []
dat_inv = zeros(length(med_val),5);

%start at the second data point
for i = 2:length(med_val)

    if  med_val(i,3) > med_val(i-1,3)
        if med_val(i,3) == dia_cut(3)
            dat_inv(i,5) = (med_val(i,2) - med_val(i-1,2))./dia_cut(4);
        elseif med_val(i,3) == dia_cut(2)
            dat_inv(i,4) = (med_val(i,2) - med_val(i-1,2))./dia_cut(3);
        elseif med_val(i,3) == dia_cut(1)
            dat_inv(i,3) = (med_val(i,2) - med_val(i-1,2))./dia_cut(2);
        else med_val(i,3) == dia_cut(4)
            dat_inv(i,2) = (med_val(i,2) - med_val(i-1,2))./dia_cut(1);
            dat_inv(i,1) = med_val(i,1);
        end
    else
        if med_val(i,3) == dia_cut(1)
            dat_inv(i,2) = (med_val(i-1,2) - med_val(i,2))./dia_cut(1);
        elseif med_val(i,3) == dia_cut(2)
            dat_inv(i,3) = (med_val(i-1,2) - med_val(i,2))./dia_cut(2);
        elseif med_val(i,3) == dia_cut(3)
            dat_inv(i,4) = (med_val(i-1,2) - med_val(i,2))./dia_cut(3);            
        elseif med_val(i,3) == dia_cut(4)
            dat_inv(i,5) = (med_val(i-1,2) - med_val(i,2))./dia_cut(4);
        end
    end
end

% Delete first row (zeros) and add to end
dat_inv(1,:) = [];
dat_inv(end+1,:) = NaN;
dat_inv(dat_inv == 0) = NaN;


%% Find average for complete scan (120*2 seconds)

% Set initial parameters (one scan = 8 rows)
scan = 8;
dat_inv_Mean = [];

for i = 1:5
    dat_invt = dat_inv(:,i);
    eleCount = numel(dat_invt);
    x = reshape(dat_invt(1:eleCount - mod(eleCount, scan)), scan, []);
    dat_inv_Meant(:,i)  = nanmean(x, 1).';
end


dat_inv = dat_inv_Meant(:,2:5);
dat_inv(dat_inv < 0) = 0;
dat_inv = dat_inv * 8.5;
timenew_avg = dat_inv_Meant(:,1);